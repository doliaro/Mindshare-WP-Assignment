Installation Instructions

This is a simple shortcode plugin, that can be activated in the Plugins
section of the wordpress navigation menu

1. Click on the plugins tab and Find the Plugin called "Mindshare Code Reveiew"
   and activate it.
2. Click on the Post tab and and a new post. In the text box call the shortcode using
   brackets [mindshare_posts]
3. Navigate to your webpage and you should see the plugin activated under your new post